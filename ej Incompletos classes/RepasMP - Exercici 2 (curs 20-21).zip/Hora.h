#pragma once

class Hora
{

};
