#include "Node.h"

class LlistaDoble
{
public:
    LlistaDoble();
    ~LlistaDoble();

	bool empty() const;
	Node* begin() const;
	Node* rbegin() const;
	Node* insert(const int &valor, Node* posicio);
	Node* erase(Node* posicio);
	void insertList(Node* posicio, int elements[], int nElements);
	void reverse();
	LlistaDoble& operator=(const LlistaDoble& llista);
private:

};