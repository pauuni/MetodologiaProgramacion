#pragma once


class SistemaUniversitari
{
public:
	SistemaUniversitari();
	~SistemaUniversitari();

	void llegirEstudiants(const char *nomFitxer);
	void llegirUniversitats(const char *nomFitxer);
	void assignacio();
	void escriureAssignacio(const char *nomFitxer);
private:

};