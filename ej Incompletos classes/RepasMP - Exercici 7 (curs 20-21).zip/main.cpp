#include "SistemaUniversitari.h"
#include <iostream>
#include <fstream>
#include <string>
using namespace std;

int main()
{
	SistemaUniversitari su;
	float grade = 0;


	cout << "Comment :=>> INICIANT TEST" << endl;
	cout << "Comment :=>> =============" << endl;
	cout << "Grade :=>> " << grade << endl;
	cout << "Comment :=>> Llegint fitxer amb dades dels estudiants....." << endl;
	su.llegirEstudiants("estudiants.txt");
	cout << "Comment :=>> Llegint fitxer amb dades de les universitats i les titulacions....." << endl;
	su.llegirUniversitats("universitats.txt");
	cout << "Comment :=>> Realitzant l'assignacio de places....." << endl;
	su.assignacio();
	cout << "Comment :=>> Escrivint resultat al fitxer 'assignacio.txt'....." << endl;
	su.escriureAssignacio("assignacio.txt");
	cout << "Comment :=>> Comparant fitxer 'assignacio.txt' amb fitxer 'assignacioResultat.txt'....." << endl;

	bool correcte = true;

	ifstream obtingut("assignacio.txt");
	ifstream esperat("assignacioResultat.txt");

	if ((obtingut.is_open()) && (esperat.is_open()))
	{
		int nLinia = 1;
		int pos;
		string liniaObtinguda, liniaEsperada;
		getline(obtingut, liniaObtinguda);
		if ((pos = liniaObtinguda.find_first_of(char(13))) < string::npos)
			liniaObtinguda = liniaObtinguda.substr(0, pos);
		getline(esperat, liniaEsperada);
		if ((pos = liniaEsperada.find_first_of(char(13))) < string::npos)
			liniaEsperada = liniaEsperada.substr(0, pos);
		while (correcte && (!obtingut.eof()) && (!esperat.eof()))
		{
			cout << "Comment :=>> Linia del ftixer: " << nLinia << endl;
			cout << "Comment :=>> Valor esperat: " << liniaEsperada << endl;
			cout << "Comment :=>> Valor obtingut: " << liniaObtinguda << endl;
			if (liniaObtinguda != liniaEsperada)
			{
				correcte = false;
				cout << "Comment :=>> ERROR" << endl;
			}
			getline(obtingut, liniaObtinguda);
			if ((pos = liniaObtinguda.find_first_of(char(13))) < string::npos)
				liniaObtinguda = liniaObtinguda.substr(0, pos);
			getline(esperat, liniaEsperada);
			if ((pos = liniaEsperada.find_first_of(char(13))) < string::npos)
				liniaEsperada = liniaEsperada.substr(0, pos);
			nLinia++;
		}
		if (correcte && ((!obtingut.eof()) || (!esperat.eof())))
		{
			correcte = false;
			cout << "Comment :=>> ERROR. FITXERS DE LONGITUD DIFERENT" << endl;
		}
	}
	else
		correcte = false;
	if (correcte)
	{
		grade = 10.0;
		cout << "Comment :=>> FINAL DEL TEST SENSE ERRORS" << endl;
		cout << "Grade :=>> " << grade << endl;
	}
	else
	{
		grade = 0.0;
		cout << "Grade :=>> " << grade << endl;
	}
	return 0;
}