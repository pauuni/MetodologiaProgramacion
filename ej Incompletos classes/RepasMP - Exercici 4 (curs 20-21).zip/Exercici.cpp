#include "Exercici.h"
#include <fstream>
using namespace std;

