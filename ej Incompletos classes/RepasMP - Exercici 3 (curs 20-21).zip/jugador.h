#pragma once

class Jugador
{
public:
	Jugador() : m_casella(1), m_potTirar(true), m_nTornsInactiu(0),
		m_guanyador(false) {}
	int posicio() const { return m_casella; }
	bool getActiu() const { return m_potTirar; }
	void mou(int casella) { m_casella = casella; }
	void guanya() { m_guanyador = true; }
	bool esGuanyador() const { return m_guanyador; }
	void setInactiu(int nTorns);
	bool potTirar();
private:
	int m_casella;
	bool m_potTirar;
	int m_nTornsInactiu;
	bool m_guanyador;
};

