#include "tauler.h"
#include <fstream>
using namespace std;

