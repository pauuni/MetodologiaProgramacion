#include "casella.h"

const int TORNS_INACTIVITAT_POU = 2;
const int CASELLA_INICIAL = 1;


bool Casella::entraJugador(Jugador& j, Casella caselles[], int nCaselles)
{

}

