#pragma once
#include "casella.h"
#include <string>
using namespace std;

const int NUMERO_CASELLES = 63;
const int NUMERO_JUGADORS = 4;
class Tauler
{
public:
	void inicialitza(const string& nomFitxer, const int& nJugadors);
	void tornJoc(int valorDau);
	int getTipusCasella(int nCasella) const { return m_caselles[nCasella].getTipus(); }
	void getEstatJugador(int nJugador, int& posicio, bool& potTirar, bool& guanyador);
private:

};