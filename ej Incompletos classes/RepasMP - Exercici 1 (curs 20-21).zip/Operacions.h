#include "Punt.h"

void distancia(Punt llistaPunts[], int nPunts, float distancies[]);
