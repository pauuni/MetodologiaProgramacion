#include "Recta.h"
#include <cmath>


