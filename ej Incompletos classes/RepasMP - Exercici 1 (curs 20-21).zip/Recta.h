#include "Punt.h"

class Recta
{

};

