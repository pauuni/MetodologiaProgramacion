#include <iostream>
using namespace std;


int main(){
    int num,sumatorio=0;
    cin>>num;
    for(int i=1; i<=num;i++){
        sumatorio=sumatorio+i;
        for(int j=1;j<=i;j++){
              if((j<=num)&&(j!=1))
              {
              cout<<"+"; 
              }
              cout<<j;
         
        }
       
        cout<<"="<<sumatorio<<endl;
    }
}