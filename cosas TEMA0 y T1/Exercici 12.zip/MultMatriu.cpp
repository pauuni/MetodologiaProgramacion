
#include "MultMatriu.h"
#include <iostream>
using namespace std;

void multiplicaMatriu(int m1[N][N],int m2[N][N],int result[N][N])
{
for (int a = 0; a < N; a++)
{
 for (int i = 0; i < N; i++)
	{
	    int suma = 0;
		for (int j = 0; j < N; j++)
		{
		    
		     suma += m1[i][j] * m2[j][a];
		    result[i][a] = suma;
		}
	}   
}
}
