#ifndef MULT_MATRIU_H
#define MULT_MATRIU_H

const int N = 3;
void multiplicaMatriu(int m1[N][N], int m2[N][N],int result[N][N]);

#endif