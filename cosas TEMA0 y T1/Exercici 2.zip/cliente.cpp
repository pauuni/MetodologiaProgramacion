#include <iostream> 
using namespace std;


bool comprobacionClient(char clasif) {
    if ((clasif != 'B') && (clasif != 'S') && (clasif != 'P')) {
        return false;
    }
    else return true;
}

int main() {
    int valorCompra, resultado;
    char tipo;
    cin >> valorCompra >> tipo;
    resultado = comprobacionClient(tipo);

    if (resultado == false)
    {
        cout << "ERROR";
    }
    else
    {
        if ((tipo == 'S') && (valorCompra > 10000))
        {
            valorCompra = valorCompra * 0.95;
        }
        else
            if ((tipo == 'P') && (valorCompra > 10000))
            {
                valorCompra = valorCompra * 0.8;
            }
        if ((tipo == 'P') && (valorCompra < 10000) && (valorCompra > 1000))
        {
            valorCompra = valorCompra * 0.9;
        }
        if ((tipo == 'P') && (valorCompra > 100) && (valorCompra < 1000))
        {
            valorCompra = valorCompra * 0.95;
        }
      cout << valorCompra;
    }

}