#include <iostream>
using namespace std;

void ordenar(int& x, int& y, int& z)
{   int menor=0,medio=0,grande=0;
    //las posibilidades para poner bien la x. Al final de esta ensalada la X esta colocada por cojones. Se puede repetir el proceso para y y z
    if((x>y) && (x>z)){
        grande=x;
    }else if (((x>y) && ( x<z)) || ((x<y) && (x>z))){
        medio=x;
    }else if((x<y) && (x<z)){
        menor=x;
    }

// -----------------------PARA Y

if((y>x) && (y>z)){
        grande=y;
    }else if (((y>x) && ( y<z)) || ((y<x) && (y>z))){
        medio=y;
    }else if((y<x) && (y<z)){
        menor=y;
    }


// -----------------------PARA Z

if((z>y) && (z>x)){
        grande=z;
    }else if (((z>y) && ( z<x)) || ((z<y) && (z>x))){
        medio=z;
    }else if((z<y) && (z<x)){
        menor=z;
    }

x = menor;
y = medio;
z = grande;
}


void display()
{
    int num1,num2,num3;
        cin>>num1>>num2>>num3;
        ordenar(num1,num2,num3);
        cout<<num1<<endl;
         cout<<num2<<endl;
          cout<<num3<<endl;
}
int main(){
   
   
    display();
}