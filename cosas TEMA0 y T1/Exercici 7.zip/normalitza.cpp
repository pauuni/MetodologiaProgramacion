void normalitzaValors(float vector[], int nValors)
{   float small=vector[0];
    float big=vector[0];
    
        for (int i=0;i<nValors;i++){
            if(vector[i]>big){
                big=vector[i];
                }
            if(vector[i]<small){
                small=vector[i];
                }
        }
    
    if((nValors!=0) && (small!=big)) {
    
        for(int j=0; j<nValors; j++){
            vector[j]=((vector[j]-small)/(big-small));
            }
    }
}
