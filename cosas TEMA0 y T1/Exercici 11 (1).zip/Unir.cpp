#include "Unir.h"
#include <stdio.h>
using namespace std;
#include <iostream>

void selectionSort(int a[], int n) {
   int i, j, min, temp;
   for (i = 0; i < n - 1; i++) {
      min = i;
      for (j = i + 1; j < n; j++)
      if (a[j] < a[min])
      min = j;
      temp = a[i];
      a[i] = a[min];
      a[min] = temp;
   }
}

void uneixOrdenadament(int vector1[], int mida1, int vector2[], int mida2, int vectorUnio[], int mida3)
{   
          int i = 0, j = 0;  
    while (i < mida1) {
        vectorUnio[i] = vector1[i];
        i += 1;
    }  
    while (j < mida2) {  
        vectorUnio[i] = vector2[j];
        j += 1;  
        i += 1;  
    }  
     selectionSort(vectorUnio, (mida1+mida2));
          
          
}


int cercaPosicio(int vector[], int mida, int valor)
{
    int i=0;
        while(valor>vector[i]){
            i++;
        }
    return i;
    
}

void afegeixOrdenadament(int vector[], int mida, int valor)
{
    int i=0;
        while(valor>vector[i]){
            i++;
        }
     vector[i]=valor;
}

void uneixOrdenadament2(int vector1[], int mida1, int vector2[], int mida2, int vectorUnio[], int mida3)
{
    //u nfor para copiar vector1 en las primeras posiciones de vctorUnio
    //un bucle en el que el primer paso es cercar posicion, mover 1 palante los que iban delante, afageixOrdenadament
                                                        //se puede implementar como un for en que el elemento j es el de cercar posicion, vectorunio[i+1]=vectorUnio[i]
      int i=0,j,temp,x, k = 0, arrayTemp[11],count=0;
      for(x=0;x<mida1;x++){
          vectorUnio[x]=vector1[x];
      }
    do{
        temp=vector2[i]; // 47
        temp=cercaPosicio(vectorUnio,mida3,temp);
        
      
            //guardamos derachaPalante en el vectortemp y luego desplazanos ek vectorUnio una a la derecha IN DESTRUIR AUN LO QUE HAVIA EN TEMP
            for(k = 0; k < mida3; k++){
                arrayTemp[k] = vectorUnio[k];
                
            }
            for(k = temp; k <= mida3; k++){
               vectorUnio[k+1]=arrayTemp[k];
            }
          afegeixOrdenadament(vectorUnio,mida3,vector2[i]);
        i++;
    }while(i<mida2);
}
