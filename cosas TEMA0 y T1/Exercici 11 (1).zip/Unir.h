#ifndef UNIR_H
#define UNIR_H

void uneixOrdenadament(int llista1[], int mida1, int llista2[], int mida2, int llistaUnio[], int mida3);
void uneixOrdenadament2(int llista1[], int mida1, int llista2[], int mida2, int llistaUnio[], int mida3);

#endif
