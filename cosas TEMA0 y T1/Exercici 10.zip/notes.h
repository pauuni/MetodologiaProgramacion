#ifndef NOTES_H
#define NOTES_H

const int MAX_NOTES = 20;

float calculaNota(float teoria, float problemes, float practiques, char& acta);
int calculaNotes(float notesFinals[], char notesActa[]);

#endif
