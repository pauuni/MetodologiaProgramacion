#include <iostream>
#include "notes.h"

using namespace std;

float calculaNota(float teoria, float problemes, float practiques, char& acta)
{   float notafinal;
   if((problemes < 0 ) || (teoria < 0 ) || (practiques < 0 )){
       notafinal= -1;
   } else {notafinal= (0.4*teoria) + (0.3*problemes) + (0.3*practiques);
       
   }
    


    if(notafinal<0){
        notafinal=-1; acta='P';
    }else if(notafinal<5){
        acta='S';
    }else if(notafinal<7){
        acta='A';
    }else if(notafinal<9){
        acta='N';
    }else if(notafinal<10){
        acta='E';
    }else acta='M';
    
    return notafinal;
}



int calculaNotes(float notesFinals[], char notesActa[])
{
    int i=0;
    float teo, pro, pra,resul;
    char act=',',malprofesor='S';
    
    while ((i<MAX_NOTES) && (malprofesor=='S')){

        cin>>teo>>pro>>pra;
        resul=calculaNota(teo,pro,pra,act);
        notesFinals[i]=resul;
        notesActa[i]=act;
        cout<<"Quieres inscribir a otro estudiante? ";
        cin>>malprofesor;
        i++;
    }
    return i;
}

