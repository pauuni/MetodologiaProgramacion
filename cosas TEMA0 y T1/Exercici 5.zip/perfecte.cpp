#include <iostream>
using namespace std;


void esPerfecte(int num){
    int acumul=0;
    
    for(int i=1; i<num; i++){
        if(num%i == 0){
            acumul=acumul+i;
        }
    } 
        if (acumul==num){
         cout<<acumul<<endl;
    }
    
}

int main(){
    int nom,count=1;
    cout<<"Introdueix un numero:";
    cin>>nom;
    cout<<"Els numeros perfectes menors son:"<<endl;
    while(count<nom){
        esPerfecte(count);
        count++;
    }
    
}