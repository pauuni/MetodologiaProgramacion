//considerar la variable global 
//que este mal redactado
#include <iostream>
using namespace std;
float result=1;

void calcExp(int x, int n){
    int i=0;
    if(n==0){
        result=1;
    }else if(n>0){
        while (i<n){
        result=result*x;
        i++; 
        } 
    }else if(n<0){
        n=(n)*(-1);
        while (i<n){
        result=result/x;
        i++;
        }
    }
    

      
   
    
}

void mostrarResult(){
    int x,n;
    cin>>x>>n;
    calcExp(x,n);
    cout<<"Resultado final "<<result;
}

int main(){
    mostrarResult();
}